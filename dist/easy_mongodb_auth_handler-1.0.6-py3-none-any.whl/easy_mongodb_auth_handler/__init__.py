"""
Allows loading as package.
"""


from .auth import Auth
